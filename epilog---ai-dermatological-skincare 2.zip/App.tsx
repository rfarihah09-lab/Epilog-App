
import React, { useState, useCallback, useEffect } from 'react';
import { AppState, UserProfile, JournalEntry } from './types';
import ProfileForm from './components/ProfileForm';
import CameraInterface from './components/CameraInterface';
import AnalysisDisplay from './components/AnalysisDisplay';
import ProductShop from './components/ProductShop';
import JournalView from './components/JournalView';
import ComparisonView from './components/ComparisonView';
import { analyzeSkin } from './services/geminiService';

const App: React.FC = () => {
  const [state, setState] = useState<AppState>(() => {
    const saved = localStorage.getItem('epilog_history');
    return {
      profile: null,
      image: null,
      analysis: null,
      products: [],
      isAnalyzing: false,
      history: saved ? JSON.parse(saved) : [],
      comparisonIds: [null, null],
      view: 'analysis'
    };
  });

  useEffect(() => {
    localStorage.setItem('epilog_history', JSON.stringify(state.history));
  }, [state.history]);

  const handleProfileSubmit = (profile: UserProfile) => {
    setState(prev => ({ ...prev, profile }));
  };

  const handleCapture = useCallback(async (imageData: string) => {
    if (!state.profile) return;
    
    setState(prev => ({ ...prev, image: imageData, isAnalyzing: true }));
    
    try {
      const result = await analyzeSkin(imageData, state.profile);
      const newEntry: JournalEntry = {
        id: crypto.randomUUID(),
        date: new Date().toISOString(),
        image: imageData,
        analysis: result.analysis
      };

      setState(prev => ({
        ...prev,
        analysis: result.analysis,
        products: result.products,
        history: [newEntry, ...prev.history],
        isAnalyzing: false,
        view: 'analysis'
      }));
    } catch (error) {
      console.error("Analysis failed:", error);
      alert("AI Analysis encountered an error. Please try a clearer image.");
      setState(prev => ({ ...prev, isAnalyzing: false, image: null }));
    }
  }, [state.profile]);

  const handleCompareSelect = (id: string) => {
    setState(prev => {
      const [id1, id2] = prev.comparisonIds;
      if (id1 === id) return { ...prev, comparisonIds: [null, id2] };
      if (id2 === id) return { ...prev, comparisonIds: [id1, null] };
      if (!id1) return { ...prev, comparisonIds: [id, id2] };
      return { ...prev, comparisonIds: [id1, id] };
    });
  };

  const selectedEntries = state.history.filter(e => state.comparisonIds.includes(e.id)) as [JournalEntry, JournalEntry];

  const reset = () => {
    if(confirm("Are you sure you want to reset? This will clear your current session but keep your journal.")) {
      setState(prev => ({
        ...prev,
        profile: null,
        image: null,
        analysis: null,
        products: [],
        isAnalyzing: false,
        view: 'analysis'
      }));
    }
  };

  return (
    <div className="min-h-screen hero-gradient flex flex-col font-sans">
      <style>{`
        @keyframes float {
          0%, 100% { transform: translateY(0) rotate(0deg); }
          50% { transform: translateY(-4px) rotate(3deg); }
        }
        .cute-float { animation: float 3s ease-in-out infinite; }
      `}</style>

      {/* Navbar */}
      <nav className="sticky top-0 z-50 glass py-4 px-8 border-b border-rose-100/30">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-10">
            <div 
              className="flex items-center gap-2.5 cursor-pointer group" 
              onClick={() => setState(prev => ({ ...prev, view: 'analysis' }))}
            >
              <div className="cute-float relative w-11 h-11 bg-rose-400 rounded-tr-[20px] rounded-bl-[20px] rounded-tl-[10px] rounded-br-[10px] flex items-center justify-center text-white shadow-[0_8px_20px_-4px_rgba(251,113,133,0.4)] transition-all group-hover:scale-105">
                <span className="font-serif italic font-bold text-2xl relative z-10">e</span>
                <div className="absolute -top-1 -right-1 w-3 h-3 bg-white rounded-full border-2 border-rose-400"></div>
              </div>
              <div className="flex flex-col -space-y-1">
                <h1 className="text-xl font-black tracking-widest text-slate-800 group-hover:text-rose-500 transition-colors">EPILOG</h1>
                <span className="text-[9px] font-bold text-rose-400 uppercase tracking-widest">Skin Care Buddy</span>
              </div>
            </div>
            
            {state.profile && (
              <div className="hidden lg:flex items-center gap-1 bg-rose-50/50 p-1 rounded-2xl border border-rose-100/50">
                <button 
                  onClick={() => setState(prev => ({ ...prev, view: 'analysis' }))}
                  className={`px-5 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${state.view === 'analysis' ? 'bg-white text-rose-500 shadow-sm' : 'text-slate-400 hover:text-rose-400'}`}
                >
                  Scanner
                </button>
                <button 
                  onClick={() => setState(prev => ({ ...prev, view: 'journal' }))}
                  className={`px-5 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${state.view === 'journal' ? 'bg-white text-rose-500 shadow-sm' : 'text-slate-400 hover:text-rose-400'}`}
                >
                  Journal
                </button>
              </div>
            )}
          </div>
          
          {state.profile && (
            <div className="flex items-center gap-5">
              {state.comparisonIds.filter(Boolean).length === 2 && (
                <button 
                  onClick={() => setState(prev => ({ ...prev, view: 'compare' }))}
                  className="bg-rose-500 text-white px-5 py-2 rounded-full text-[10px] font-black uppercase tracking-widest shadow-lg shadow-rose-200 hover:bg-rose-600 transition-all transform hover:scale-105 active:scale-95"
                >
                  ✨ Compare ✨
                </button>
              )}
              <div className="hidden sm:flex flex-col items-end">
                <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest leading-none mb-1">Sweetheart</p>
                <p className="text-sm font-bold text-slate-700">{state.profile.name}</p>
              </div>
              <button 
                onClick={reset}
                className="w-10 h-10 flex items-center justify-center hover:bg-rose-50 rounded-full text-slate-400 hover:text-rose-500 transition-all"
                title="Restart Session"
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
                </svg>
              </button>
            </div>
          )}
        </div>
      </nav>

      <main className="flex-grow pb-24">
        {!state.profile ? (
          <div className="py-20">
            <ProfileForm onSubmit={handleProfileSubmit} />
          </div>
        ) : state.isAnalyzing ? (
          <div className="flex flex-col items-center justify-center py-32 animate-in fade-in duration-1000">
            <div className="relative w-40 h-40 mb-12">
              <div className="absolute inset-0 border-[6px] border-rose-100 rounded-[2.5rem]"></div>
              <div className="absolute inset-0 border-[6px] border-rose-500 rounded-[2.5rem] border-t-transparent animate-spin"></div>
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="w-16 h-16 bg-rose-50 rounded-full animate-pulse"></div>
              </div>
            </div>
            <h2 className="text-3xl font-light text-slate-800 tracking-tight">AI Clinical <span className="text-rose-500 font-bold">Sequencing</span></h2>
            <p className="text-slate-500 mt-3 text-lg font-light">Mapping facial topography and lipid barriers...</p>
          </div>
        ) : state.view === 'journal' ? (
          <div className="py-12">
            <JournalView 
              history={state.history} 
              onCompareSelect={handleCompareSelect}
              selectedIds={state.comparisonIds}
              onViewDetails={(entry) => setState(prev => ({ ...prev, view: 'analysis', image: entry.image, analysis: entry.analysis }))}
            />
          </div>
        ) : !state.image ? (
          <div className="py-20">
            <CameraInterface onCapture={handleCapture} />
          </div>
        ) : (
          <div className="animate-in fade-in slide-in-from-bottom-8 duration-700">
            {state.analysis && state.image && (
              <>
                <AnalysisDisplay analysis={state.analysis} image={state.image} />
                <ProductShop products={state.products} />
                <div className="flex justify-center mt-12 mb-20">
                  <button 
                    onClick={() => setState(prev => ({ ...prev, image: null, analysis: null }))}
                    className="group flex items-center gap-3 px-10 py-5 bg-slate-900 text-white rounded-[2rem] font-black uppercase tracking-widest hover:bg-rose-500 transition-all transform hover:-translate-y-1 active:scale-95 shadow-2xl"
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 group-hover:rotate-180 transition-transform duration-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                    </svg>
                    Initialize New Scan
                  </button>
                </div>
              </>
            )}
          </div>
        )}
      </main>

      {state.view === 'compare' && selectedEntries.length === 2 && (
        <ComparisonView 
          entries={selectedEntries} 
          onClose={() => setState(prev => ({ ...prev, view: 'journal' }))} 
        />
      )}

      <footer className="text-center py-12 border-t border-rose-100 bg-white/40">
        <div className="max-w-7xl mx-auto px-8 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 bg-rose-400 rounded-tr-lg rounded-bl-lg"></div>
            <span className="text-[10px] font-black tracking-[0.3em] text-slate-800">EPILOG BEAUTY</span>
          </div>
          <p className="text-slate-400 text-[10px] font-bold uppercase tracking-widest">
            MADE WITH LOVE & AI &copy; 2024
          </p>
          <div className="flex gap-6">
            <span className="text-slate-300 text-[10px] font-bold uppercase tracking-widest">Privacy</span>
            <span className="text-slate-300 text-[10px] font-bold uppercase tracking-widest">Journaling</span>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default App;
